/**
 * Home Component Tests
 *
 * Comprehensive test suite for the Home component covering:
 * - Component rendering with all UI elements
 * - Form handling and input change events
 * - Form submission with validation
 * - Logout functionality
 * - Modal, Tabs, Accordion state management
 * - Pagination and Stepper interactions
 * - Accessibility features
 * - Error scenarios
 */

import { describe, it, expect, beforeEach, vi } from 'vitest'
import { render, screen, waitFor, within } from '@testing-library/react'
import userEvent from '@testing-library/user-event'
import { BrowserRouter } from 'react-router-dom'
import Home from './Home'

/**
 * Wrapper component for Router context
 * The Home component uses useNavigate hook, so it must be wrapped with BrowserRouter
 */
const renderWithRouter = (component: React.ReactElement) => {
    return render(<BrowserRouter>{component}</BrowserRouter>)
}

/**
 * Mock useNavigate hook for logout testing
 */
vi.mock('react-router-dom', async () => {
    const actual = await vi.importActual('react-router-dom')
    return {
        ...actual,
        useNavigate: () => vi.fn(),
    }
})

describe('Home Component', () => {
    beforeEach(() => {
        // Clear session and local storage before each test
        sessionStorage.clear()
        localStorage.removeItem('authToken')
    })

    /**
     * RENDERING TESTS
     * Verify that all main sections and components render correctly
     */

    describe('Component Rendering', () => {
        it('should render the main heading and subtitle', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /component showcase/i })).toBeInTheDocument()
            expect(
                screen.getByText(/explore all available components and their variants/i)
            ).toBeInTheDocument()
        })

        it('should render logout button with proper accessibility attributes', () => {
            renderWithRouter(<Home />)

            const logoutButton = screen.getByRole('button', { name: /logout/i })
            expect(logoutButton).toBeInTheDocument()
            expect(logoutButton).toHaveAttribute('aria-label', 'Logout and return to login page')
        })

        it('should render Profile Information Form section', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /profile information form/i })).toBeInTheDocument()
        })

        it('should render form input fields', () => {
            renderWithRouter(<Home />)

            expect(screen.getByLabelText(/first name/i)).toBeInTheDocument()
            expect(screen.getByLabelText(/last name/i)).toBeInTheDocument()
            expect(screen.getByLabelText(/phone number/i)).toBeInTheDocument()
        })

        it('should render Buttons section with multiple button variants', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^buttons$/i })).toBeInTheDocument()
            expect(screen.getByRole('button', { name: /primary contained/i })).toBeInTheDocument()
            expect(screen.getByRole('button', { name: /secondary contained/i })).toBeInTheDocument()
            expect(screen.getByRole('button', { name: /primary outlined/i })).toBeInTheDocument()
        })

        it('should render Text Fields section', () => {
            renderWithRouter(<Home />)

            const headings = screen.getAllByRole('heading', { name: /text fields/i })
            expect(headings.length).toBeGreaterThan(0)
        })

        it('should render Tabs section', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^tabs$/i })).toBeInTheDocument()
            expect(screen.getByRole('tab', { name: /tab 1/i })).toBeInTheDocument()
        })

        it('should render Modal section with Open Modal button', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^modal$/i })).toBeInTheDocument()
            expect(screen.getByRole('button', { name: /open modal/i })).toBeInTheDocument()
        })

        it('should render Accordion section', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^accordion$/i })).toBeInTheDocument()
        })

        it('should render Pagination section with page navigation', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^pagination$/i })).toBeInTheDocument()
            expect(screen.getByLabelText(/go to page 1/i)).toBeInTheDocument()
        })

        it('should render Stepper section', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^stepper$/i })).toBeInTheDocument()
        })

        it('should render Typography section with heading variants', () => {
            renderWithRouter(<Home />)

            expect(screen.getByRole('heading', { name: /^typography$/i })).toBeInTheDocument()
            expect(screen.getByRole('heading', { name: /^heading 1$/i })).toBeInTheDocument()
        })
    })

    /**
     * FORM INTERACTION TESTS
     * Test form input changes, validation, and submission
     */

    describe('Form Interactions', () => {
        it('should update form data when text field value changes', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            await user.type(firstNameInput, 'John')

            expect(firstNameInput).toHaveValue('John')
        })

        it('should update multiple form fields', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const lastNameInput = screen.getByLabelText(/last name/i)

            await user.type(firstNameInput, 'John')
            await user.type(lastNameInput, 'Doe')

            expect(firstNameInput).toHaveValue('John')
            expect(lastNameInput).toHaveValue('Doe')
        })

        it('should clear error message when field is corrected', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)

            // Submit form to trigger validation
            const submitButton = screen.getByRole('button', { name: /submit form/i })
            await user.click(submitButton)

            // Wait for potential error state
            await waitFor(() => {
                expect(firstNameInput).toHaveAttribute('value', '')
            })

            // Type valid input
            await user.type(firstNameInput, 'John')

            expect(firstNameInput).toHaveValue('John')
        })

        it('should handle checkbox toggle', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const subscribeCheckbox = screen.getByRole('checkbox', { name: /subscribe/i })

            await user.click(subscribeCheckbox)
            expect(subscribeCheckbox).toBeChecked()

            await user.click(subscribeCheckbox)
            expect(subscribeCheckbox).not.toBeChecked()
        })

        it('should reset form when Reset button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const resetButton = screen.getByRole('button', { name: /reset/i })

            await user.type(firstNameInput, 'John')
            expect(firstNameInput).toHaveValue('John')

            await user.click(resetButton)

            await waitFor(() => {
                expect(firstNameInput).toHaveValue('')
            })
        })

        it('should submit form with valid data', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const lastNameInput = screen.getByLabelText(/last name/i)
            const phoneInput = screen.getByLabelText(/phone number/i)
            const submitButton = screen.getByRole('button', { name: /submit form/i })

            await user.type(firstNameInput, 'John')
            await user.type(lastNameInput, 'Doe')
            await user.type(phoneInput, '1234567890')

            // Mock console.log to verify form submission
            const consoleSpy = vi.spyOn(console, 'log')

            await user.click(submitButton)

            await waitFor(() => {
                expect(consoleSpy).toHaveBeenCalledWith(
                    'Form Validation Result:',
                    expect.objectContaining({
                        status: expect.any(Boolean),
                        data: expect.any(Array),
                    })
                )
            })

            consoleSpy.mockRestore()
        })
    })

    /**
     * MODAL TESTS
     * Test modal open/close functionality
     */

    describe('Modal Functionality', () => {
        it('should open modal when Open Modal button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const openModalButton = screen.getByRole('button', { name: /open modal/i })
            await user.click(openModalButton)

            expect(screen.getByRole('heading', { name: /modal title/i })).toBeInTheDocument()
            expect(screen.getByText(/this is modal content/i)).toBeInTheDocument()
        })

        it('should close modal when Close Modal button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const openModalButton = screen.getByRole('button', { name: /open modal/i })
            await user.click(openModalButton)

            const closeModalButton = screen.getByRole('button', { name: /close modal/i })
            await user.click(closeModalButton)

            await waitFor(() => {
                expect(screen.queryByRole('heading', { name: /modal title/i })).not.toBeInTheDocument()
            })
        })
    })

    /**
     * TABS TESTS
     * Test tab selection and content switching
     */

    describe('Tabs Functionality', () => {
        it('should display Tab 1 content by default', () => {
            renderWithRouter(<Home />)

            expect(screen.getByText(/content for tab 1/i)).toBeInTheDocument()
        })

        it('should switch to Tab 2 content when clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const tab2 = screen.getByRole('tab', { name: /tab 2/i })
            await user.click(tab2)

            expect(screen.getByText(/content for tab 2/i)).toBeInTheDocument()
        })

        it('should switch to Tab 3 content when clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const tab3 = screen.getByRole('tab', { name: /tab 3/i })
            await user.click(tab3)

            expect(screen.getByText(/content for tab 3/i)).toBeInTheDocument()
        })
    })

    /**
     * ACCORDION TESTS
     * Test accordion expand/collapse functionality
     */

    describe('Accordion Functionality', () => {
        it('should have closed accordions by default', () => {
            renderWithRouter(<Home />)

            const accordionTitles = screen.getAllByText(/accordion item/i)
            expect(accordionTitles.length).toBeGreaterThan(0)
        })

        it('should expand accordion when clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const accordionItem1 = screen.getByRole('button', { name: /accordion item 1/i })
            await user.click(accordionItem1)

            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()
        })

        it('should collapse accordion when clicked again', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const accordionItem1 = screen.getByRole('button', { name: /accordion item 1/i })

            // Open accordion
            await user.click(accordionItem1)
            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()

            // Close accordion
            await user.click(accordionItem1)

            await waitFor(() => {
                expect(
                    screen.queryByText(/this is the content for accordion item 1/i)
                ).not.toBeInTheDocument()
            })
        })

        it('should handle multiple accordions independently', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const accordionItem1 = screen.getByRole('button', { name: /accordion item 1/i })
            const accordionItem2 = screen.getByRole('button', { name: /accordion item 2/i })

            await user.click(accordionItem1)
            await user.click(accordionItem2)

            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()
            expect(
                screen.getByText(/this is the content for accordion item 2/i)
            ).toBeInTheDocument()
        })
    })

    /**
     * PAGINATION TESTS
     * Test pagination page selection
     */

    describe('Pagination Functionality', () => {
        it('should display page 3 as default current page', () => {
            renderWithRouter(<Home />)

            expect(screen.getByText(/current page: 3/i)).toBeInTheDocument()
        })

        it('should update current page when page button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const page1Button = screen.getByRole('button', { name: /go to page 1/i })
            await user.click(page1Button)

            expect(screen.getByText(/current page: 1/i)).toBeInTheDocument()
        })

        it('should update to different pages sequentially', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const page2Button = screen.getByRole('button', { name: /go to page 2/i })
            await user.click(page2Button)
            expect(screen.getByText(/current page: 2/i)).toBeInTheDocument()

            const page5Button = screen.getByRole('button', { name: /go to page 5/i })
            await user.click(page5Button)
            expect(screen.getByText(/current page: 5/i)).toBeInTheDocument()
        })
    })

    /**
     * STEPPER TESTS
     * Test stepper step navigation
     */

    describe('Stepper Functionality', () => {
        it('should display initial step information', () => {
            renderWithRouter(<Home />)

            expect(screen.getByText(/current step: step 1 - initial setup/i)).toBeInTheDocument()
        })

        it('should navigate to next step when Next button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const nextButton = screen.getAllByRole('button', { name: /next/i })[0]
            await user.click(nextButton)

            expect(screen.getByText(/current step: step 2 - configuration/i)).toBeInTheDocument()
        })

        it('should navigate to previous step when Previous button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            // First, move to step 2
            const nextButton = screen.getAllByRole('button', { name: /next/i })[0]
            await user.click(nextButton)

            // Then go back to step 1
            const prevButton = screen.getAllByRole('button', { name: /previous/i })[0]
            await user.click(prevButton)

            expect(screen.getByText(/current step: step 1 - initial setup/i)).toBeInTheDocument()
        })

        it('should disable Previous button on first step', () => {
            renderWithRouter(<Home />)

            const prevButtons = screen.getAllByRole('button', { name: /previous/i })
            const prevButton = prevButtons[0]

            expect(prevButton).toBeDisabled()
        })

        it('should disable Next button on last step', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const nextButtons = screen.getAllByRole('button', { name: /next/i })
            let nextButton = nextButtons[0]

            // Navigate to last step
            for (let i = 0; i < 3; i++) {
                await user.click(nextButton)
                const updatedNextButtons = screen.getAllByRole('button', { name: /next/i })
                nextButton = updatedNextButtons[0]
            }

            expect(nextButton).toBeDisabled()
        })
    })

    /**
     * SNACKBAR TESTS
     * Test snackbar notification display
     */

    describe('Snackbar Functionality', () => {
        it('should display snackbar when Show Snackbar button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const snackbarButton = screen.getByRole('button', { name: /show snackbar/i })
            await user.click(snackbarButton)

            expect(screen.getByText(/this is a snackbar notification/i)).toBeInTheDocument()
        })

        it('should display snackbar when form is successfully submitted', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const lastNameInput = screen.getByLabelText(/last name/i)
            const phoneInput = screen.getByLabelText(/phone number/i)
            const submitButton = screen.getByRole('button', { name: /submit form/i })

            await user.type(firstNameInput, 'John')
            await user.type(lastNameInput, 'Doe')
            await user.type(phoneInput, '1234567890')
            await user.click(submitButton)

            await waitFor(() => {
                expect(screen.getByText(/this is a snackbar notification/i)).toBeInTheDocument()
            })
        })
    })

    /**
     * MENU TESTS
     * Test menu button interactions
     */

    describe('Menu Functionality', () => {
        it('should toggle menu when menu button is clicked', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const menuButtons = screen.getAllByRole('button', { name: /open menu/i })
            const firstMenuButton = menuButtons[0]

            await user.click(firstMenuButton)

            const updatedMenuButtons = screen.queryAllByRole('button', { name: /close menu/i })
            expect(updatedMenuButtons.length).toBeGreaterThan(0)
        })
    })

    /**
     * LOGOUT TESTS
     * Test logout functionality
     */

    describe('Logout Functionality', () => {
        it('should clear session storage on logout', async () => {
            const user = userEvent.setup()

            // Set some session data
            sessionStorage.setItem('sessionData', 'test')
            expect(sessionStorage.getItem('sessionData')).toBe('test')

            renderWithRouter(<Home />)

            const logoutButton = screen.getByRole('button', { name: /logout/i })
            await user.click(logoutButton)

            expect(sessionStorage.getItem('sessionData')).toBeNull()
        })

        it('should remove authToken from localStorage on logout', async () => {
            const user = userEvent.setup()

            // Set auth token
            localStorage.setItem('authToken', 'test-token')
            expect(localStorage.getItem('authToken')).toBe('test-token')

            renderWithRouter(<Home />)

            const logoutButton = screen.getByRole('button', { name: /logout/i })
            await user.click(logoutButton)

            expect(localStorage.getItem('authToken')).toBeNull()
        })
    })

    /**
     * ACCESSIBILITY TESTS
     * Verify accessibility features and WCAG compliance
     */

    describe('Accessibility Features', () => {
        it('should have proper page structure with landmarks', () => {
            renderWithRouter(<Home />)

            // Check for main content area (implicit in the component structure)
            expect(screen.getByRole('heading', { name: /component showcase/i })).toBeInTheDocument()
        })

        it('should have accessible form with required field indicators', () => {
            renderWithRouter(<Home />)

            // Check for labels
            expect(screen.getByLabelText(/first name/i)).toBeInTheDocument()
            expect(screen.getByLabelText(/last name/i)).toBeInTheDocument()
        })

        it('should have keyboard navigable elements', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)

            // Tab to the first input field
            await user.tab()

            // Input should be in the document and keyboard accessible
            expect(firstNameInput).toBeInTheDocument()
        })

        it('should provide aria-labels for interactive elements', () => {
            renderWithRouter(<Home />)

            const logoutButton = screen.getByRole('button', { name: /logout/i })
            expect(logoutButton).toHaveAttribute('aria-label')
        })

        it('should have proper heading hierarchy', () => {
            renderWithRouter(<Home />)

            const h1 = screen.getByRole('heading', { level: 1 })
            expect(h1).toHaveTextContent(/component showcase/i)

            const h2s = screen.getAllByRole('heading', { level: 2 })
            expect(h2s.length).toBeGreaterThan(0)
        })

        it('should have pagination with proper aria-labels', () => {
            renderWithRouter(<Home />)

            const paginationNav = screen.getByRole('navigation', { name: /pagination navigation/i })
            expect(paginationNav).toBeInTheDocument()

            expect(screen.getByRole('button', { name: /go to page 1/i })).toBeInTheDocument()
            expect(screen.getByRole('button', { name: /go to page 2/i })).toBeInTheDocument()
        })

        it('should have proper table semantics', () => {
            renderWithRouter(<Home />)

            const table = screen.getByRole('table', { name: /sample data table/i })
            expect(table).toBeInTheDocument()
        })
    })

    /**
     * INTEGRATION TESTS
     * Test complex interactions between multiple features
     */

    describe('Integration Tests', () => {
        it('should handle form submission and show snackbar notification', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const lastNameInput = screen.getByLabelText(/last name/i)
            const phoneInput = screen.getByLabelText(/phone number/i)
            const submitButton = screen.getByRole('button', { name: /submit form/i })

            await user.type(firstNameInput, 'John')
            await user.type(lastNameInput, 'Doe')
            await user.type(phoneInput, '1234567890')

            await user.click(submitButton)

            await waitFor(() => {
                expect(screen.getByText(/this is a snackbar notification/i)).toBeInTheDocument()
            })
        })

        it('should allow user to navigate between tabs and interact with form', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            // Navigate to Tab 2
            const tab2 = screen.getByRole('tab', { name: /tab 2/i })
            await user.click(tab2)
            expect(screen.getByText(/content for tab 2/i)).toBeInTheDocument()

            // Return to Tab 1 (form visible)
            const tab1 = screen.getByRole('tab', { name: /tab 1/i })
            await user.click(tab1)
            expect(screen.getByText(/content for tab 1/i)).toBeInTheDocument()

            // Interact with form
            const firstNameInput = screen.getByLabelText(/first name/i)
            await user.type(firstNameInput, 'John')
            expect(firstNameInput).toHaveValue('John')
        })

        it('should handle multiple accordion and tab interactions', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            // Open accordion
            const accordionItem1 = screen.getByRole('button', { name: /accordion item 1/i })
            await user.click(accordionItem1)
            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()

            // Change tabs
            const tab2 = screen.getByRole('tab', { name: /tab 2/i })
            await user.click(tab2)

            // Accordion state should be independent
            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()
        })

        it('should manage stepper and modal interactions independently', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            // Open modal
            const openModalButton = screen.getByRole('button', { name: /open modal/i })
            await user.click(openModalButton)
            expect(screen.getByRole('heading', { name: /modal title/i })).toBeInTheDocument()

            // Navigate stepper (not affected by modal)
            const nextButton = screen.getAllByRole('button', { name: /next/i })[0]
            await user.click(nextButton)

            // Close modal
            const closeModalButton = screen.getByRole('button', { name: /close modal/i })
            await user.click(closeModalButton)

            // Stepper should still be on step 2
            expect(screen.getByText(/current step: step 2 - configuration/i)).toBeInTheDocument()
        })
    })

    /**
     * EDGE CASES & ERROR SCENARIOS
     */

    describe('Edge Cases & Error Scenarios', () => {
        it('should handle rapid form input changes', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)

            await user.type(firstNameInput, 'J')
            await user.type(firstNameInput, 'o')
            await user.type(firstNameInput, 'h')
            await user.type(firstNameInput, 'n')

            expect(firstNameInput).toHaveValue('John')
        })

        it('should handle tab navigation with all accordion items', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const accordionItems = screen.getAllByRole('button').filter((btn) =>
                btn.textContent?.includes('Accordion Item')
            )

            // Open all accordion items
            for (const item of accordionItems) {
                await user.click(item)
            }

            // All should be expanded
            expect(
                screen.getByText(/this is the content for accordion item 1/i)
            ).toBeInTheDocument()
            expect(
                screen.getByText(/this is the content for accordion item 2/i)
            ).toBeInTheDocument()
            expect(
                screen.getByText(/this is the content for accordion item 3/i)
            ).toBeInTheDocument()
        })

        it('should handle form reset after submission', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const firstNameInput = screen.getByLabelText(/first name/i)
            const lastNameInput = screen.getByLabelText(/last name/i)
            const phoneInput = screen.getByLabelText(/phone number/i)
            const submitButton = screen.getByRole('button', { name: /submit form/i })

            // Fill form
            await user.type(firstNameInput, 'John')
            await user.type(lastNameInput, 'Doe')
            await user.type(phoneInput, '1234567890')

            // Submit
            await user.click(submitButton)

            // Wait for form to reset
            await waitFor(() => {
                expect(firstNameInput).toHaveValue('')
            })
        })

        it('should maintain pagination state across page selections', async () => {
            const user = userEvent.setup()
            renderWithRouter(<Home />)

            const page5Button = screen.getByRole('button', { name: /go to page 5/i })
            await user.click(page5Button)
            expect(screen.getByText(/current page: 5/i)).toBeInTheDocument()

            const page2Button = screen.getByRole('button', { name: /go to page 2/i })
            await user.click(page2Button)
            expect(screen.getByText(/current page: 2/i)).toBeInTheDocument()

            // Return to page 5
            await user.click(page5Button)
            expect(screen.getByText(/current page: 5/i)).toBeInTheDocument()
        })
    })
})
