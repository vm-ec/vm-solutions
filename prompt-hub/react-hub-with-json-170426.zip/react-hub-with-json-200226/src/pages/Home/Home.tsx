/**
 * Home Component - Component Showcase
 *
 * Purpose: Comprehensive showcase and demonstration page for all available components.
 * Displays all UI components with various states, sizes, and variants.
 * Includes logout functionality to return to the login page.
 *
 * Props: None
 *
 * Behavior:
 *   - Displays all components in organized sections
 *   - Shows various component states and variants
 *   - Provides logout button to clear session and return to login
 *   - Accessible layout with semantic HTML and ARIA attributes
 *   - Responsive design for various screen sizes
 */

import { useState, type ChangeEvent, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import homeConfig from '../../config/home.json';
import { deepClone } from '../../scripts/utils';
import { validateFormFields } from '../../scripts/validationsService';
import {
  Card,
  CardContent,
  Typography,
  Button,
  TextField,
  Select,
  Checkbox,
  Modal,
  NumberField,
  Link,
  RadioGroup,
  Tabs,
  Tab,
  Tooltip,
  Pagination,
  Accordion,
  Table,
  Stepper,
  Snackbar,
  Menu,
  AutoComplete
} from '../../components';

type FormDataType = typeof homeConfig;

const Home = () => {
  const navigate = useNavigate();
  const clonedHomeConfig = deepClone(homeConfig);

  // Initialize form data from home.json configuration
  const [formData, setFormData] = useState<FormDataType>(clonedHomeConfig);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const [accordion1Open, setAccordion1Open] = useState(false);
  const [accordion2Open, setAccordion2Open] = useState(false);
  const [accordion3Open, setAccordion3Open] = useState(false);
  const [currentPage, setCurrentPage] = useState(3);
  const [activeStep, setActiveStep] = useState(0);
  const [menuOpen, setMenuOpen] = useState(false);

  /**
   * Handle form field changes - unified handler for all input types
   * Updates formData state with new value and clears validation errors
   */
  const handleFieldChange = (fieldId: string, fieldValue: string | boolean) => {
    setFormData(prevData => ({
      ...prevData,
      [fieldId as keyof FormDataType]: {
        ...prevData[fieldId as keyof FormDataType],
        value: fieldValue,
        hasError: false,
        errorMessage: '',
      },
    }));
  };

  /**
   * Handle input field change events (text, radio, checkbox, select)
   */
  const handleInputChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type, id } = e.target as HTMLInputElement;
    const isCheckbox = type === 'checkbox';
    const fieldValue = isCheckbox ? (e.target as HTMLInputElement).checked : value;
    const fieldId = type === 'radio' ? name : id;
    handleFieldChange(fieldId, fieldValue);
  };

  /**
   * Handle AutoComplete option selection
   */
  const handleAutoCompleteSelect = (fieldName: keyof FormDataType) => (option: { value: string; label: string }) => {
    handleFieldChange(fieldName, option.value);
  };

  /**
   * Handle form submission
   */
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const { data, status } = validateFormFields(formData);

    console.log('Form Validation Result:', { data, status });

    if (status) {
      setSnackbarOpen(true);
      setFormData(clonedHomeConfig);
    } else {
      setFormData(prevData =>
        Object.entries(prevData).reduce((acc, [key, field], index) => {
          const validationResult = data[index] as
            | { isValid: boolean; errorMessage?: string }
            | undefined;
          return {
            ...acc,
            [key]: {
              ...field,
              hasError: !validationResult?.isValid,
              errorMessage: validationResult?.errorMessage || '',
            },
          };
        }, {} as FormDataType),
      );
    }
  };

  /**
   * Handle logout action
   */
  const handleLogout = () => {
    sessionStorage.clear();
    localStorage.removeItem('authToken');
    navigate('/login');
  };

  // Sample table data
  const tableColumns = [
    { field: 'id', headerName: 'ID', width: 80 },
    { field: 'name', headerName: 'Name', width: 150 },
    { field: 'role', headerName: 'Role', width: 150 },
    { field: 'status', headerName: 'Status', width: 120 },
  ];

  const tableRows = [
    { id: 1, name: 'John Doe', role: 'Developer', status: 'Active' },
    { id: 2, name: 'Jane Smith', role: 'Designer', status: 'Active' },
    { id: 3, name: 'Bob Johnson', role: 'Manager', status: 'Inactive' },
  ];

  // Stepper steps
  const stepperSteps = [
    { label: 'Step 1', description: 'Initial Setup' },
    { label: 'Step 2', description: 'Configuration' },
    { label: 'Step 3', description: 'Verification' },
    { label: 'Step 4', description: 'Completion' },
  ];

  return (
    <div className='min-h-screen w-full bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 p-8'>
      <div className='max-w-7xl mx-auto'>
        {/* Header */}
        <div className='mb-8'>
          <Typography variant='h1' className='text-center text-gray-900 mb-4'>
            Component Showcase
          </Typography>
          <Typography variant='body1' className='text-center text-gray-600 mb-6'>
            Explore all available components and their variants
          </Typography>
          <div className='flex justify-end gap-4'>
            <Button
              variant='outlined'
              color='primary'
              onClick={handleLogout}
              aria-label='Logout and return to login page'
            >
              Logout
            </Button>
          </div>
        </div>

        {/* Input Form Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Profile Information Form
            </Typography>
          </CardContent>
          <form onSubmit={handleSubmit} noValidate>
            <CardContent className='grid grid-cols-3 gap-6 mb-6'>
              <TextField
                {...formData.firstName}
                onChange={handleInputChange}
              />
              <TextField
                {...formData.lastName}
                onChange={handleInputChange}
              />
              <TextField
                {...formData.phoneNumber}
                onChange={handleInputChange}
              />
              <NumberField
                {...formData.experience}
                onChange={handleInputChange}
              />
              <Select
                {...formData.department}
                onChange={handleInputChange}
              >
              </Select>
              <RadioGroup
                id={formData.role.id}
                name={formData.role.name}
                label={formData.role.label}
                value={formData.role.value}
                required={formData.role.isRequired}
                hasError={formData.role.hasError}
                errorMessage={formData.role.errorMessage}
                options={formData.role.options}
                onChange={handleInputChange}
              />
              <AutoComplete
                {...formData.city}
                onSelect={handleAutoCompleteSelect('city')}
              />
            </CardContent>

            {/* Checkbox wrapper */}
            <CardContent className='pt-0'>
              <Checkbox
                {...formData.subscribe}
                onChange={handleInputChange}
              />
            </CardContent>

            <CardContent className='border-t border-gray-200 bg-gray-50 flex gap-4 mt-6'>
              <Button variant='contained' color='primary' type='submit'>
                Submit Form
              </Button>
              <Button
                variant='outlined'
                color='primary'
                type='button'
                onClick={() => setFormData(clonedHomeConfig)}
              >
                Reset
              </Button>
            </CardContent>
          </form>
        </Card>
        {/* Buttons Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Buttons
            </Typography>
          </CardContent>
          <CardContent className='flex flex-wrap gap-4'>
            <Button variant='contained' color='primary'>
              Primary Contained
            </Button>
            <Button variant='contained' color='secondary'>
              Secondary Contained
            </Button>
            <Button variant='outlined' color='primary'>
              Primary Outlined
            </Button>
            <Button variant='text' color='primary'>
              Text Button
            </Button>
            <Button variant='contained' disabled>
              Disabled
            </Button>
            <Button size='small' variant='contained' color='primary'>
              Small
            </Button>
            <Button size='large' variant='contained' color='primary'>
              Large
            </Button>
          </CardContent>
        </Card>

        {/* Text Fields Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Text Fields
            </Typography>
          </CardContent>
          <CardContent className='grid grid-cols-2 gap-6'>
            <TextField label='Default Text Field' placeholder='Enter text' />
            <TextField label='Email Field' type='email' placeholder='Enter email' />
            <TextField label='Password Field' type='password' placeholder='Enter password' />
            <TextField label='Disabled Field' disabled placeholder='Disabled' />
            <TextField
              label='Field with Error'
              hasError={true}
              errorMessage='This field is required'
              value='Invalid input'
            />
            <TextField label='Required Field' isRequired placeholder='This is required' />
          </CardContent>
        </Card>

        {/* Select Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Select Dropdowns
            </Typography>
          </CardContent>
          <CardContent className='grid grid-cols-2 gap-6'>
            <Select label='Default Select' defaultValue=''>
              <option value=''>Select an option</option>
              <option value='1'>Option 1</option>
              <option value='2'>Option 2</option>
              <option value='3'>Option 3</option>
            </Select>
            <Select label='Select Size Small' size='sm' defaultValue='1'>
              <option value='1'>Small Option</option>
              <option value='2'>Small Option 2</option>
            </Select>
            <Select label='Select Size Large' size='lg' defaultValue='1'>
              <option value='1'>Large Option</option>
              <option value='2'>Large Option 2</option>
            </Select>
            <Select label='Disabled Select' disabled defaultValue='1'>
              <option value='1'>Disabled Option</option>
            </Select>
          </CardContent>
        </Card>

        {/* Checkboxes Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Checkboxes
            </Typography>
          </CardContent>
          <CardContent className='flex flex-col gap-4'>
            <Checkbox label='Default Checkbox' />
            <Checkbox label='Checked Checkbox' defaultChecked />
            <Checkbox label='Disabled Checkbox' disabled />
            <Checkbox label='Large Checkbox' size='lg' />
            <Checkbox label='Small Checkbox' size='sm' />
            <Checkbox label='Required Checkbox' isRequired />
          </CardContent>
        </Card>

        {/* Radio Group Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Radio Groups
            </Typography>
          </CardContent>
          <CardContent className='grid grid-cols-2 gap-6'>
            <RadioGroup label='Select Size' size='sm'>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='size-options' value='small' defaultChecked /> Small
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='size-options' value='medium' /> Medium
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='size-options' value='large' /> Large
              </label>
            </RadioGroup>

            <RadioGroup label='Select Color' size='sm'>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='color-options' value='red' defaultChecked /> Red
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='color-options' value='blue' /> Blue
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='color-options' value='green' /> Green
              </label>
            </RadioGroup>

            <RadioGroup label='Options Medium' size='md'>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='medium-options' value='yes' defaultChecked /> Yes
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='medium-options' value='no' /> No
              </label>
            </RadioGroup>

            <RadioGroup label='Options Large' size='lg'>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='large-options' value='agree' defaultChecked /> I Agree
              </label>
              <label style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                <input type='radio' name='large-options' value='disagree' /> I Disagree
              </label>
            </RadioGroup>
          </CardContent>
        </Card>

        {/* Links Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Links
            </Typography>
          </CardContent>
          <CardContent className='flex flex-wrap gap-6'>
            <Link to='/'>Default Link</Link>
            <Link to='/' color='primary'>
              Primary Link
            </Link>
            <Link to='/' color='secondary'>
              Secondary Link
            </Link>
            <Link to='/' underline='hover'>
              Underline on Hover
            </Link>
            <Link to='/' size='lg'>
              Large Link
            </Link>
          </CardContent>
        </Card>

        {/* Number Field Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Number Fields
            </Typography>
          </CardContent>
          <CardContent className='grid grid-cols-2 gap-6'>
            <NumberField label='Default Number Field' placeholder='Enter a number' />
            <NumberField label='With Min/Max' min={0} max={100} />
            <NumberField label='With Step' step={5} />
            <NumberField label='Disabled' disabled />
          </CardContent>
        </Card>

        {/* Tabs Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Tabs
            </Typography>
          </CardContent>
          <CardContent>
            <Tabs value={activeTab} onChange={(value) => setActiveTab(value as number)}>
              <Tab value={0} label='Tab 1' />
              <Tab value={1} label='Tab 2' />
              <Tab value={2} label='Tab 3' />
            </Tabs>
            <div className='mt-6 p-4 bg-gray-50 rounded'>
              {activeTab === 0 && <Typography variant='body1'>Content for Tab 1</Typography>}
              {activeTab === 1 && <Typography variant='body1'>Content for Tab 2</Typography>}
              {activeTab === 2 && <Typography variant='body1'>Content for Tab 3</Typography>}
            </div>
          </CardContent>
        </Card>

        {/* Modal Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Modal
            </Typography>
          </CardContent>
          <CardContent>
            <Button variant='contained' color='primary' onClick={() => setIsModalOpen(true)}>
              Open Modal
            </Button>
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)}>
              <div className='p-6'>
                <Typography variant='h3' className='mb-4'>
                  Modal Title
                </Typography>
                <Typography variant='body1' className='mb-6'>
                  This is modal content. Click the close button or outside to close.
                </Typography>
                <Button
                  variant='contained'
                  color='primary'
                  onClick={() => setIsModalOpen(false)}
                >
                  Close Modal
                </Button>
              </div>
            </Modal>
          </CardContent>
        </Card>

        {/* Tooltip Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Tooltips
            </Typography>
          </CardContent>
          <CardContent className='flex flex-wrap gap-8'>
            <Tooltip title='This is a tooltip'>
              <span className='px-4 py-2 bg-blue-100 rounded cursor-help'>Hover me</span>
            </Tooltip>
            <Tooltip title='Top tooltip' placement='top'>
              <span className='px-4 py-2 bg-green-100 rounded cursor-help'>Top tooltip</span>
            </Tooltip>
            <Tooltip title='Bottom tooltip' placement='bottom'>
              <span className='px-4 py-2 bg-purple-100 rounded cursor-help'>Bottom tooltip</span>
            </Tooltip>
            <Tooltip title='Left tooltip' placement='left'>
              <span className='px-4 py-2 bg-pink-100 rounded cursor-help'>Left tooltip</span>
            </Tooltip>
            <Tooltip title='Right tooltip' placement='right'>
              <span className='px-4 py-2 bg-yellow-100 rounded cursor-help'>Right tooltip</span>
            </Tooltip>
          </CardContent>
        </Card>

        {/* Pagination Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Pagination
            </Typography>
          </CardContent>
          <CardContent className='flex flex-wrap gap-2'>
            <nav aria-label='Pagination navigation'>
              <Pagination value='1' aria-label='Go to page 1' onClick={() => setCurrentPage(1)} selected={currentPage === 1} />
              <Pagination value='2' aria-label='Go to page 2' onClick={() => setCurrentPage(2)} selected={currentPage === 2} />
              <Pagination value='3' aria-label='Go to page 3' onClick={() => setCurrentPage(3)} selected={currentPage === 3} aria-current='page' />
              <Pagination value='4' aria-label='Go to page 4' onClick={() => setCurrentPage(4)} selected={currentPage === 4} />
              <Pagination value='5' aria-label='Go to page 5' onClick={() => setCurrentPage(5)} selected={currentPage === 5} />
            </nav>
            <div className='w-full mt-4 p-3 bg-blue-50 rounded text-sm'>
              <Typography variant='body2' className='text-gray-700'>
                Current Page: {currentPage}
              </Typography>
            </div>
          </CardContent>
        </Card>

        {/* Accordion Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Accordion
            </Typography>
          </CardContent>
          <CardContent className='flex flex-col gap-4'>
            <Accordion
              title='Accordion Item 1'
              isOpen={accordion1Open}
              onChange={setAccordion1Open}
            >
              <Typography variant='body2' className='text-gray-600'>
                This is the content for accordion item 1. Click to expand or collapse.
              </Typography>
            </Accordion>
            <Accordion
              title='Accordion Item 2'
              isOpen={accordion2Open}
              onChange={setAccordion2Open}
            >
              <Typography variant='body2' className='text-gray-600'>
                This is the content for accordion item 2. Click to expand or collapse.
              </Typography>
            </Accordion>
            <Accordion
              title='Accordion Item 3'
              isOpen={accordion3Open}
              onChange={setAccordion3Open}
            >
              <Typography variant='body2' className='text-gray-600'>
                This is the content for accordion item 3. Click to expand or collapse.
              </Typography>
            </Accordion>
          </CardContent>
        </Card>

        {/* Table Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Table
            </Typography>
          </CardContent>
          <CardContent>
            <Table columns={tableColumns} rows={tableRows} aria-label='Sample data table' />
          </CardContent>
        </Card>

        {/* Stepper Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Stepper
            </Typography>
          </CardContent>
          <CardContent>
            <Stepper
              steps={stepperSteps}
              value={activeStep}
              onClick={(stepIndex) => setActiveStep(stepIndex)}
            />
            <div className='mt-6 p-4 bg-blue-50 rounded'>
              <Typography variant='body2' className='text-gray-600'>
                Current Step: {stepperSteps[activeStep]?.label} - {stepperSteps[activeStep]?.description}
              </Typography>
              <div className='flex gap-2 mt-4'>
                <Button
                  variant='outlined'
                  color='primary'
                  size='small'
                  disabled={activeStep === 0}
                  onClick={() => setActiveStep(activeStep - 1)}
                >
                  Previous
                </Button>
                <Button
                  variant='contained'
                  color='primary'
                  size='small'
                  disabled={activeStep === stepperSteps.length - 1}
                  onClick={() => setActiveStep(activeStep + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Snackbar Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Snackbar
            </Typography>
          </CardContent>
          <CardContent>
            <Button
              variant='contained'
              color='primary'
              onClick={() => setSnackbarOpen(true)}
            >
              Show Snackbar
            </Button>
            <Snackbar
              open={snackbarOpen}
              onClose={() => setSnackbarOpen(false)}
              position='bottom-right'
              autoHideDuration={3000}
            >
              <span>This is a snackbar notification!</span>
            </Snackbar>
          </CardContent>
        </Card>

        {/* Menu Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Menu Buttons
            </Typography>
          </CardContent>
          <CardContent className='flex flex-wrap gap-4'>
            <div className='relative'>
              <Menu size='md' variant='primary' onClick={() => setMenuOpen(!menuOpen)}>
                {menuOpen ? 'Close Menu' : 'Open Menu'}
              </Menu>
              {menuOpen && (
                <div className='absolute top-12 left-0 bg-white border border-gray-300 rounded shadow-lg z-10 min-w-48'>
                  <button
                    className='block w-full text-left px-4 py-2 hover:bg-blue-50 border-b'
                    onClick={() => {
                      setMenuOpen(false);
                    }}
                  >
                    Edit
                  </button>
                  <button
                    className='block w-full text-left px-4 py-2 hover:bg-blue-50 border-b'
                    onClick={() => {
                      setMenuOpen(false);
                    }}
                  >
                    Delete
                  </button>
                  <button
                    className='block w-full text-left px-4 py-2 hover:bg-blue-50'
                    onClick={() => {
                      setMenuOpen(false);
                    }}
                  >
                    Share
                  </button>
                </div>
              )}
            </div>
            <Menu size='md' variant='secondary'>
              Secondary
            </Menu>
            <Menu size='md' variant='danger'>
              Danger
            </Menu>
            <Menu size='sm'>
              Small
            </Menu>
            <Menu size='lg'>
              Large
            </Menu>
          </CardContent>
        </Card>

        {/* Typography Section */}
        <Card className='mb-8'>
          <CardContent className='pb-0'>
            <Typography variant='h2' className='text-gray-900 mb-6'>
              Typography
            </Typography>
          </CardContent>
          <CardContent className='flex flex-col gap-4'>
            <Typography variant='h1'>Heading 1</Typography>
            <Typography variant='h2'>Heading 2</Typography>
            <Typography variant='h3'>Heading 3</Typography>
            <Typography variant='h4'>Heading 4</Typography>
            <Typography variant='body1'>Body 1 - Regular text</Typography>
            <Typography variant='body2'>Body 2 - Small text</Typography>
            <Typography variant='caption'>Caption - Very small text</Typography>
          </CardContent>
        </Card>

        {/* Footer */}
        <div className='text-center mt-12 pb-8'>
          <Typography variant='body2' className='text-gray-600'>
            End of Component Showcase
          </Typography>
        </div>
      </div>
    </div>
  );
};

export default Home;
