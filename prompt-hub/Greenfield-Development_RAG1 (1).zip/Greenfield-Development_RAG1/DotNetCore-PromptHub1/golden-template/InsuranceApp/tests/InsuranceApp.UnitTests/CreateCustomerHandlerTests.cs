using InsuranceApp.Application.Customers.Commands;
using InsuranceApp.Domain.Interfaces;
using Moq;

namespace InsuranceApp.UnitTests.Customers;

public class CreateCustomerHandlerTests
{
    private readonly Mock<IUnitOfWork> _unitOfWorkMock = new();
    private readonly Mock<ICustomerRepository> _customerRepoMock = new();

    public CreateCustomerHandlerTests()
    {
        _unitOfWorkMock.Setup(u => u.Customers).Returns(_customerRepoMock.Object);
    }

    [Fact]
    public async Task Handle_WhenEmailIsUnique_ReturnsSuccess()
    {
        _customerRepoMock.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), default)).ReturnsAsync(false);

        var handler = new CreateCustomerHandler(_unitOfWorkMock.Object);
        var command = new CreateCustomerCommand("John", "Doe", "john@example.com", "1234567890", new DateTime(1990, 1, 1));

        var result = await handler.Handle(command, default);

        Assert.True(result.IsSuccess);
        Assert.NotNull(result.Data);
        Assert.Equal("John", result.Data.FirstName);
    }

    [Fact]
    public async Task Handle_WhenEmailAlreadyExists_ReturnsFailure()
    {
        _customerRepoMock.Setup(r => r.ExistsByEmailAsync(It.IsAny<string>(), default)).ReturnsAsync(true);

        var handler = new CreateCustomerHandler(_unitOfWorkMock.Object);
        var command = new CreateCustomerCommand("John", "Doe", "john@example.com", "1234567890", new DateTime(1990, 1, 1));

        var result = await handler.Handle(command, default);

        Assert.False(result.IsSuccess);
        Assert.Contains("already exists", result.ErrorMessage);
    }
}
