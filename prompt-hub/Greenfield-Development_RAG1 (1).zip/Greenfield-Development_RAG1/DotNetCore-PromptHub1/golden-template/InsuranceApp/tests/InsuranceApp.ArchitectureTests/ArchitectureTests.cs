using NetArchTest.Rules;
using Xunit;

namespace InsuranceApp.ArchitectureTests;

/// <summary>
/// Enforces Clean Architecture dependency rules — these tests will FAIL if any layer
/// references a layer it should not depend on.
/// </summary>
public class ArchitectureTests
{
    private const string DomainNamespace = "InsuranceApp.Domain";
    private const string ApplicationNamespace = "InsuranceApp.Application";
    private const string InfrastructureNamespace = "InsuranceApp.Infrastructure";
    private const string ApiNamespace = "InsuranceApp.API";

    [Fact]
    public void Domain_ShouldNot_HaveDependencyOn_Application()
    {
        var result = Types.InNamespace(DomainNamespace)
            .ShouldNot().HaveDependencyOn(ApplicationNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Domain must not reference Application.");
    }

    [Fact]
    public void Domain_ShouldNot_HaveDependencyOn_Infrastructure()
    {
        var result = Types.InNamespace(DomainNamespace)
            .ShouldNot().HaveDependencyOn(InfrastructureNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Domain must not reference Infrastructure.");
    }

    [Fact]
    public void Domain_ShouldNot_HaveDependencyOn_API()
    {
        var result = Types.InNamespace(DomainNamespace)
            .ShouldNot().HaveDependencyOn(ApiNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Domain must not reference API.");
    }

    [Fact]
    public void Application_ShouldNot_HaveDependencyOn_Infrastructure()
    {
        var result = Types.InNamespace(ApplicationNamespace)
            .ShouldNot().HaveDependencyOn(InfrastructureNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Application must not reference Infrastructure.");
    }

    [Fact]
    public void Application_ShouldNot_HaveDependencyOn_API()
    {
        var result = Types.InNamespace(ApplicationNamespace)
            .ShouldNot().HaveDependencyOn(ApiNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Application must not reference API.");
    }

    [Fact]
    public void Infrastructure_ShouldNot_HaveDependencyOn_API()
    {
        var result = Types.InNamespace(InfrastructureNamespace)
            .ShouldNot().HaveDependencyOn(ApiNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Infrastructure must not reference API.");
    }

    [Fact]
    public void Controllers_ShouldNot_HaveDirectDependencyOn_Domain()
    {
        // Controllers should talk to Application (MediatR), not Domain directly
        var result = Types.InNamespace($"{ApiNamespace}.Controllers")
            .ShouldNot().HaveDependencyOn(DomainNamespace)
            .GetResult();

        Assert.True(result.IsSuccessful, "Controllers must not reference Domain directly — use MediatR commands/queries.");
    }
}
