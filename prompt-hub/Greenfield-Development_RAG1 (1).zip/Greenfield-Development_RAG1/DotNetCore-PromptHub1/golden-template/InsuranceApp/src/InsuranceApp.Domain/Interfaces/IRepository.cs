using InsuranceApp.Domain.Entities;

namespace InsuranceApp.Domain.Interfaces;

public interface IRepository<T> where T : BaseEntity
{
    Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default);
    Task<IEnumerable<T>> GetAllAsync(CancellationToken cancellationToken = default);
    Task AddAsync(T entity, CancellationToken cancellationToken = default);
    void Update(T entity);
    void Remove(T entity);
    Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default);
}

public interface ICustomerRepository : IRepository<Customer>
{
    Task<Customer?> GetByEmailAsync(string email, CancellationToken cancellationToken = default);
    Task<bool> ExistsByEmailAsync(string email, CancellationToken cancellationToken = default);
}

public interface IPolicyRepository : IRepository<Policy>
{
    Task<IEnumerable<Policy>> GetByCustomerIdAsync(int customerId, CancellationToken cancellationToken = default);
}

public interface IClaimRepository : IRepository<Claim>
{
    Task<IEnumerable<Claim>> GetByPolicyIdAsync(int policyId, CancellationToken cancellationToken = default);
}

public interface IUnitOfWork : IDisposable
{
    ICustomerRepository Customers { get; }
    IPolicyRepository Policies { get; }
    IClaimRepository Claims { get; }
    Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
}
