namespace InsuranceApp.Domain.Enums;

public enum CustomerStatus { Active = 1, Inactive = 2 }
public enum PolicyType { Auto = 1, Home = 2, Life = 3, Health = 4 }
public enum PolicyStatus { Active = 1, Expired = 2, Cancelled = 3 }
public enum ClaimStatus { Pending = 1, Approved = 2, Rejected = 3 }
