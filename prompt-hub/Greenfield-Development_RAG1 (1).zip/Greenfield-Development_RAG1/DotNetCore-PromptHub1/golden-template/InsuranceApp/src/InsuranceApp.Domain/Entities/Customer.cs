using InsuranceApp.Domain.Enums;
using InsuranceApp.Domain.Events;
using InsuranceApp.Domain.Exceptions;
using InsuranceApp.Domain.Interfaces;
using InsuranceApp.Domain.ValueObjects;

namespace InsuranceApp.Domain.Entities;

public class Customer : BaseEntity, IAggregateRoot
{
    public string FirstName { get; private set; } = string.Empty;
    public string LastName { get; private set; } = string.Empty;
    public Email Email { get; private set; } = null!;
    public string Phone { get; private set; } = string.Empty;
    public DateTime DateOfBirth { get; private set; }
    public CustomerStatus Status { get; private set; }

    private readonly List<Policy> _policies = new();
    public IReadOnlyCollection<Policy> Policies => _policies.AsReadOnly();

    private Customer() { }

    public Customer(string firstName, string lastName, Email email, string phone, DateTime dateOfBirth)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(firstName);
        ArgumentException.ThrowIfNullOrWhiteSpace(lastName);
        ArgumentException.ThrowIfNullOrWhiteSpace(phone);

        FirstName = firstName;
        LastName = lastName;
        Email = email ?? throw new ArgumentNullException(nameof(email));
        Phone = phone;
        DateOfBirth = dateOfBirth;
        Status = CustomerStatus.Active;

        RaiseDomainEvent(new CustomerCreatedEvent(Id, FullName, email.Value));
    }

    public string FullName => $"{FirstName} {LastName}";

    public void UpdateContactInfo(string phone, Email email)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(phone);
        Phone = phone;
        Email = email ?? throw new ArgumentNullException(nameof(email));
        UpdateTimestamp();
    }

    public void Deactivate()
    {
        if (Status is CustomerStatus.Inactive)
            throw new DomainException("Customer is already inactive.");

        Status = CustomerStatus.Inactive;
        UpdateTimestamp();

        RaiseDomainEvent(new CustomerDeactivatedEvent(Id));
    }
}
