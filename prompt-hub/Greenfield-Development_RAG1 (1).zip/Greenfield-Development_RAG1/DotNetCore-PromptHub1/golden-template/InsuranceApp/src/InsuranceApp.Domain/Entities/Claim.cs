using InsuranceApp.Domain.Enums;
using InsuranceApp.Domain.Events;
using InsuranceApp.Domain.Exceptions;
using InsuranceApp.Domain.Interfaces;

namespace InsuranceApp.Domain.Entities;

public class Claim : BaseEntity, IAggregateRoot
{
    public string ClaimNumber { get; private set; } = string.Empty;
    public decimal ClaimAmount { get; private set; }
    public string Description { get; private set; } = string.Empty;
    public DateTime ClaimDate { get; private set; }
    public ClaimStatus Status { get; private set; }
    public int PolicyId { get; private set; }

    public Policy Policy { get; private set; } = null!;

    private Claim() { }

    public Claim(string claimNumber, decimal claimAmount, string description, DateTime claimDate, int policyId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(claimNumber);
        ArgumentException.ThrowIfNullOrWhiteSpace(description);

        if (claimAmount <= 0) throw new DomainException("Claim amount must be greater than zero.");

        ClaimNumber = claimNumber;
        ClaimAmount = claimAmount;
        Description = description;
        ClaimDate = claimDate;
        PolicyId = policyId;
        Status = ClaimStatus.Pending;
    }

    public void Approve()
    {
        if (Status is not ClaimStatus.Pending)
            throw new DomainException("Only pending claims can be approved.");

        Status = ClaimStatus.Approved;
        UpdateTimestamp();

        RaiseDomainEvent(new ClaimApprovedEvent(Id, ClaimNumber, ClaimAmount));
    }

    public void Reject()
    {
        if (Status is not ClaimStatus.Pending)
            throw new DomainException("Only pending claims can be rejected.");

        Status = ClaimStatus.Rejected;
        UpdateTimestamp();

        RaiseDomainEvent(new ClaimRejectedEvent(Id, ClaimNumber));
    }
}
