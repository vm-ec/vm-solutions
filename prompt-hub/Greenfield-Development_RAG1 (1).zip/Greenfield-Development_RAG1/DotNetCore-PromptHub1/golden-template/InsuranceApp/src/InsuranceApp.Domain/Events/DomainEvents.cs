using InsuranceApp.Domain.Interfaces;

namespace InsuranceApp.Domain.Events;

public abstract class DomainEvent : IDomainEvent
{
    public Guid Id { get; } = Guid.NewGuid();
    public DateTime OccurredAt { get; } = DateTime.UtcNow;
}

/// <summary>Raised when a new customer is registered in the system.</summary>
public class CustomerCreatedEvent : DomainEvent
{
    public int CustomerId { get; }
    public string FullName { get; }
    public string Email { get; }

    public CustomerCreatedEvent(int customerId, string fullName, string email)
    {
        CustomerId = customerId;
        FullName = fullName;
        Email = email;
    }
}

/// <summary>Raised when a customer is deactivated.</summary>
public class CustomerDeactivatedEvent : DomainEvent
{
    public int CustomerId { get; }

    public CustomerDeactivatedEvent(int customerId)
    {
        CustomerId = customerId;
    }
}

/// <summary>Raised when a policy is cancelled.</summary>
public class PolicyCancelledEvent : DomainEvent
{
    public int PolicyId { get; }
    public string PolicyNumber { get; }
    public int CustomerId { get; }

    public PolicyCancelledEvent(int policyId, string policyNumber, int customerId)
    {
        PolicyId = policyId;
        PolicyNumber = policyNumber;
        CustomerId = customerId;
    }
}

/// <summary>Raised when a claim is approved.</summary>
public class ClaimApprovedEvent : DomainEvent
{
    public int ClaimId { get; }
    public string ClaimNumber { get; }
    public decimal ClaimAmount { get; }

    public ClaimApprovedEvent(int claimId, string claimNumber, decimal claimAmount)
    {
        ClaimId = claimId;
        ClaimNumber = claimNumber;
        ClaimAmount = claimAmount;
    }
}

/// <summary>Raised when a claim is rejected.</summary>
public class ClaimRejectedEvent : DomainEvent
{
    public int ClaimId { get; }
    public string ClaimNumber { get; }

    public ClaimRejectedEvent(int claimId, string claimNumber)
    {
        ClaimId = claimId;
        ClaimNumber = claimNumber;
    }
}
