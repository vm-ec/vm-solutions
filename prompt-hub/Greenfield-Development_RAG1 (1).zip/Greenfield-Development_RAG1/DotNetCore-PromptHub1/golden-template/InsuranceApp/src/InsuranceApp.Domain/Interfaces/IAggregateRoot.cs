namespace InsuranceApp.Domain.Interfaces;

/// <summary>
/// Marker interface to identify aggregate roots — only aggregate roots should be accessed via repositories.
/// </summary>
public interface IAggregateRoot { }

/// <summary>
/// Base interface for all domain events raised by aggregate roots.
/// </summary>
public interface IDomainEvent
{
    Guid Id { get; }
    DateTime OccurredAt { get; }
}
