using InsuranceApp.Domain.Enums;
using InsuranceApp.Domain.Events;
using InsuranceApp.Domain.Exceptions;
using InsuranceApp.Domain.Interfaces;

namespace InsuranceApp.Domain.Entities;

public class Policy : BaseEntity, IAggregateRoot
{
    public string PolicyNumber { get; private set; } = string.Empty;
    public PolicyType Type { get; private set; }
    public decimal Premium { get; private set; }
    public decimal CoverageAmount { get; private set; }
    public DateTime StartDate { get; private set; }
    public DateTime EndDate { get; private set; }
    public PolicyStatus Status { get; private set; }
    public int CustomerId { get; private set; }

    public Customer Customer { get; private set; } = null!;

    private readonly List<Claim> _claims = new();
    public IReadOnlyCollection<Claim> Claims => _claims.AsReadOnly();

    private Policy() { }

    public Policy(string policyNumber, PolicyType type, decimal premium, decimal coverageAmount,
        DateTime startDate, DateTime endDate, int customerId)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(policyNumber);

        if (premium <= 0) throw new DomainException("Premium must be greater than zero.");
        if (coverageAmount <= 0) throw new DomainException("Coverage amount must be greater than zero.");
        if (endDate <= startDate) throw new DomainException("End date must be after start date.");

        PolicyNumber = policyNumber;
        Type = type;
        Premium = premium;
        CoverageAmount = coverageAmount;
        StartDate = startDate;
        EndDate = endDate;
        CustomerId = customerId;
        Status = PolicyStatus.Active;
    }

    public void UpdatePremium(decimal newPremium)
    {
        if (newPremium <= 0) throw new DomainException("Premium must be greater than zero.");
        Premium = newPremium;
        UpdateTimestamp();
    }

    public void Cancel()
    {
        if (Status is PolicyStatus.Cancelled)
            throw new DomainException("Policy is already cancelled.");

        Status = PolicyStatus.Cancelled;
        UpdateTimestamp();

        RaiseDomainEvent(new PolicyCancelledEvent(Id, PolicyNumber, CustomerId));
    }
}
