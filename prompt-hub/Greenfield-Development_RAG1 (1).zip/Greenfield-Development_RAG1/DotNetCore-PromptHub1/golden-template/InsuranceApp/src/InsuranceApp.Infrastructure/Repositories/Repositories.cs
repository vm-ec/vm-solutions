using InsuranceApp.Domain.Entities;
using InsuranceApp.Domain.Interfaces;
using InsuranceApp.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;

namespace InsuranceApp.Infrastructure.Repositories;

// ── Generic Repository ────────────────────────────────────────────────────────

public class Repository<T> : IRepository<T> where T : BaseEntity
{
    protected readonly ApplicationDbContext _context;
    protected readonly DbSet<T> _dbSet;

    public Repository(ApplicationDbContext context)
    {
        _context = context;
        _dbSet = context.Set<T>();
    }

    public async Task<T?> GetByIdAsync(int id, CancellationToken cancellationToken = default) =>
        await _dbSet.FindAsync(new object[] { id }, cancellationToken);

    public async Task<IEnumerable<T>> GetAllAsync(CancellationToken cancellationToken = default) =>
        await _dbSet.ToListAsync(cancellationToken);

    public async Task AddAsync(T entity, CancellationToken cancellationToken = default) =>
        await _dbSet.AddAsync(entity, cancellationToken);

    public void Update(T entity) => _dbSet.Update(entity);

    public void Remove(T entity) => entity.MarkAsDeleted();

    public async Task<bool> ExistsAsync(int id, CancellationToken cancellationToken = default) =>
        await _dbSet.AnyAsync(e => e.Id == id, cancellationToken);
}

// ── Customer Repository ───────────────────────────────────────────────────────

public class CustomerRepository : Repository<Customer>, ICustomerRepository
{
    public CustomerRepository(ApplicationDbContext context) : base(context) { }

    public async Task<Customer?> GetByEmailAsync(string email, CancellationToken cancellationToken = default) =>
        await _dbSet.FirstOrDefaultAsync(c => c.Email.Value == email, cancellationToken);

    public async Task<bool> ExistsByEmailAsync(string email, CancellationToken cancellationToken = default) =>
        await _dbSet.AnyAsync(c => c.Email.Value == email, cancellationToken);
}

// ── Policy Repository ─────────────────────────────────────────────────────────

public class PolicyRepository : Repository<Policy>, IPolicyRepository
{
    public PolicyRepository(ApplicationDbContext context) : base(context) { }

    public async Task<IEnumerable<Policy>> GetByCustomerIdAsync(int customerId, CancellationToken cancellationToken = default) =>
        await _dbSet.Where(p => p.CustomerId == customerId).ToListAsync(cancellationToken);
}

// ── Claim Repository ──────────────────────────────────────────────────────────

public class ClaimRepository : Repository<Claim>, IClaimRepository
{
    public ClaimRepository(ApplicationDbContext context) : base(context) { }

    public async Task<IEnumerable<Claim>> GetByPolicyIdAsync(int policyId, CancellationToken cancellationToken = default) =>
        await _dbSet.Where(c => c.PolicyId == policyId).ToListAsync(cancellationToken);
}

// ── Unit of Work ──────────────────────────────────────────────────────────────

public class UnitOfWork : IUnitOfWork
{
    private readonly ApplicationDbContext _context;

    public UnitOfWork(ApplicationDbContext context)
    {
        _context = context;
        Customers = new CustomerRepository(context);
        Policies = new PolicyRepository(context);
        Claims = new ClaimRepository(context);
    }

    public ICustomerRepository Customers { get; }
    public IPolicyRepository Policies { get; }
    public IClaimRepository Claims { get; }

    public async Task<int> SaveChangesAsync(CancellationToken cancellationToken = default) =>
        await _context.SaveChangesAsync(cancellationToken);

    public void Dispose() => _context.Dispose();
}
