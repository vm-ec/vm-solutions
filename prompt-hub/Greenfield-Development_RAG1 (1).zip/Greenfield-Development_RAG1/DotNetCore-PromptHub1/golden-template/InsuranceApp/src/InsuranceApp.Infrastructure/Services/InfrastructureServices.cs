using InsuranceApp.Application.Common.Interfaces;
using Microsoft.Extensions.Logging;

namespace InsuranceApp.Infrastructure.Services;

/// <summary>
/// Infrastructure implements the IEmailService contract defined in Application.
/// Swap this for SendGrid, SMTP, etc. without touching Application or Domain.
/// </summary>
public class EmailService : IEmailService
{
    private readonly ILogger<EmailService> _logger;

    public EmailService(ILogger<EmailService> logger)
    {
        _logger = logger;
    }

    public Task SendWelcomeEmailAsync(string email, string fullName, CancellationToken cancellationToken = default)
    {
        // Replace with real email provider (SendGrid, SMTP, etc.)
        _logger.LogInformation("Sending welcome email to {Email} for {FullName}", email, fullName);
        return Task.CompletedTask;
    }

    public Task SendClaimApprovedEmailAsync(string email, string claimNumber, decimal amount, CancellationToken cancellationToken = default)
    {
        _logger.LogInformation("Sending claim approved email to {Email} for claim {ClaimNumber}", email, claimNumber);
        return Task.CompletedTask;
    }
}

/// <summary>
/// Infrastructure implements IDateTimeProvider — allows mocking DateTime.UtcNow in tests.
/// </summary>
public class DateTimeProvider : IDateTimeProvider
{
    public DateTime UtcNow => DateTime.UtcNow;
}
