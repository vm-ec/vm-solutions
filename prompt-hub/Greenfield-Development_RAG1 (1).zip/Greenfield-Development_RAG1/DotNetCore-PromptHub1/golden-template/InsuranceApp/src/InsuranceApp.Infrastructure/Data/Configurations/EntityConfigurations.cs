using InsuranceApp.Domain.Entities;
using InsuranceApp.Domain.ValueObjects;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace InsuranceApp.Infrastructure.Data.Configurations;

public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.HasKey(c => c.Id);

        builder.Property(c => c.FirstName).IsRequired().HasMaxLength(100);
        builder.Property(c => c.LastName).IsRequired().HasMaxLength(100);
        builder.Property(c => c.Phone).IsRequired().HasMaxLength(20);

        builder.OwnsOne(c => c.Email, email =>
        {
            email.Property(e => e.Value).HasColumnName("Email").IsRequired().HasMaxLength(200);
            email.HasIndex(e => e.Value).IsUnique();
        });

        builder.HasMany(c => c.Policies)
            .WithOne(p => p.Customer)
            .HasForeignKey(p => p.CustomerId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasQueryFilter(c => !c.IsDeleted);
    }
}

public class PolicyConfiguration : IEntityTypeConfiguration<Policy>
{
    public void Configure(EntityTypeBuilder<Policy> builder)
    {
        builder.HasKey(p => p.Id);
        builder.Property(p => p.PolicyNumber).IsRequired().HasMaxLength(50);
        builder.HasIndex(p => p.PolicyNumber).IsUnique();
        builder.Property(p => p.Premium).HasColumnType("decimal(18,2)");
        builder.Property(p => p.CoverageAmount).HasColumnType("decimal(18,2)");

        builder.HasMany(p => p.Claims)
            .WithOne(c => c.Policy)
            .HasForeignKey(c => c.PolicyId)
            .OnDelete(DeleteBehavior.Restrict);

        builder.HasQueryFilter(p => !p.IsDeleted);
    }
}

public class ClaimConfiguration : IEntityTypeConfiguration<Claim>
{
    public void Configure(EntityTypeBuilder<Claim> builder)
    {
        builder.HasKey(c => c.Id);
        builder.Property(c => c.ClaimNumber).IsRequired().HasMaxLength(50);
        builder.HasIndex(c => c.ClaimNumber).IsUnique();
        builder.Property(c => c.ClaimAmount).HasColumnType("decimal(18,2)");
        builder.Property(c => c.Description).HasMaxLength(500);

        builder.HasQueryFilter(c => !c.IsDeleted);
    }
}
