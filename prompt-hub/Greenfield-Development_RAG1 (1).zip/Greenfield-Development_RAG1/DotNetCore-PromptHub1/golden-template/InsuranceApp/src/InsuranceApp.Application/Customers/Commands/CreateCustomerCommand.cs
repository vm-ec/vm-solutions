using FluentValidation;
using InsuranceApp.Application.Common.Models;
using InsuranceApp.Domain.Entities;
using InsuranceApp.Domain.Interfaces;
using InsuranceApp.Domain.ValueObjects;
using MediatR;

namespace InsuranceApp.Application.Customers.Commands;

// ── DTOs ──────────────────────────────────────────────────────────────────────

public record CustomerDto(int Id, string FirstName, string LastName, string Email, string Phone, DateTime DateOfBirth, string Status, DateTime CreatedAt);

// ── Command ───────────────────────────────────────────────────────────────────

public record CreateCustomerCommand(string FirstName, string LastName, string Email, string Phone, DateTime DateOfBirth)
    : IRequest<Result<CustomerDto>>;

// ── Validator ─────────────────────────────────────────────────────────────────

public class CreateCustomerValidator : AbstractValidator<CreateCustomerCommand>
{
    public CreateCustomerValidator()
    {
        RuleFor(x => x.FirstName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.LastName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.Phone).NotEmpty().MaximumLength(20);
        RuleFor(x => x.DateOfBirth).LessThan(DateTime.UtcNow);
    }
}

// ── Handler ───────────────────────────────────────────────────────────────────

public class CreateCustomerHandler : IRequestHandler<CreateCustomerCommand, Result<CustomerDto>>
{
    private readonly IUnitOfWork _unitOfWork;

    public CreateCustomerHandler(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<CustomerDto>> Handle(CreateCustomerCommand request, CancellationToken cancellationToken)
    {
        if (await _unitOfWork.Customers.ExistsByEmailAsync(request.Email, cancellationToken))
            return Result<CustomerDto>.Failure("A customer with this email already exists.");

        var customer = new Customer(request.FirstName, request.LastName, new Email(request.Email), request.Phone, request.DateOfBirth);

        await _unitOfWork.Customers.AddAsync(customer, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result<CustomerDto>.Success(MapToDto(customer));
    }

    private static CustomerDto MapToDto(Customer c) =>
        new(c.Id, c.FirstName, c.LastName, c.Email.Value, c.Phone, c.DateOfBirth, c.Status.ToString(), c.CreatedAt);
}
