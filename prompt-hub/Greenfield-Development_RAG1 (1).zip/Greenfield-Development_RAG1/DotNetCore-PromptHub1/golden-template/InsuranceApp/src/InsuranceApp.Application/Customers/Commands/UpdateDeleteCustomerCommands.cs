using FluentValidation;
using InsuranceApp.Application.Common.Models;
using InsuranceApp.Application.Customers.Commands;
using InsuranceApp.Domain.Exceptions;
using InsuranceApp.Domain.Interfaces;
using InsuranceApp.Domain.ValueObjects;
using MediatR;

namespace InsuranceApp.Application.Customers.Commands;

// ── Update Command ────────────────────────────────────────────────────────────

public record UpdateCustomerCommand(int Id, string FirstName, string LastName, string Email, string Phone)
    : IRequest<Result<CustomerDto>>;

public class UpdateCustomerValidator : AbstractValidator<UpdateCustomerCommand>
{
    public UpdateCustomerValidator()
    {
        RuleFor(x => x.Id).GreaterThan(0);
        RuleFor(x => x.FirstName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.LastName).NotEmpty().MaximumLength(100);
        RuleFor(x => x.Email).NotEmpty().EmailAddress();
        RuleFor(x => x.Phone).NotEmpty().MaximumLength(20);
    }
}

public class UpdateCustomerHandler : IRequestHandler<UpdateCustomerCommand, Result<CustomerDto>>
{
    private readonly IUnitOfWork _unitOfWork;

    public UpdateCustomerHandler(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<CustomerDto>> Handle(UpdateCustomerCommand request, CancellationToken cancellationToken)
    {
        var customer = await _unitOfWork.Customers.GetByIdAsync(request.Id, cancellationToken);

        if (customer is null)
            return Result<CustomerDto>.Failure($"Customer with ID {request.Id} was not found.");

        customer.UpdateContactInfo(request.Phone, new Email(request.Email));
        _unitOfWork.Customers.Update(customer);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result<CustomerDto>.Success(
            new(customer.Id, customer.FirstName, customer.LastName, customer.Email.Value,
                customer.Phone, customer.DateOfBirth, customer.Status.ToString(), customer.CreatedAt));
    }
}

// ── Delete Command ────────────────────────────────────────────────────────────

public record DeleteCustomerCommand(int Id) : IRequest<Result<bool>>;

public class DeleteCustomerHandler : IRequestHandler<DeleteCustomerCommand, Result<bool>>
{
    private readonly IUnitOfWork _unitOfWork;

    public DeleteCustomerHandler(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<bool>> Handle(DeleteCustomerCommand request, CancellationToken cancellationToken)
    {
        var customer = await _unitOfWork.Customers.GetByIdAsync(request.Id, cancellationToken);

        if (customer is null)
            return Result<bool>.Failure($"Customer with ID {request.Id} was not found.");

        // Soft delete via domain method
        _unitOfWork.Customers.Remove(customer);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result<bool>.Success(true);
    }
}
