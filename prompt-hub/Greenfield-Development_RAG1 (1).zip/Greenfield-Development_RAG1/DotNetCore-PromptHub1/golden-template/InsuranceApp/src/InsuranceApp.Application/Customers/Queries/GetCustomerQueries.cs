using InsuranceApp.Application.Common.Models;
using InsuranceApp.Application.Customers.Commands;
using InsuranceApp.Domain.Exceptions;
using InsuranceApp.Domain.Interfaces;
using MediatR;

namespace InsuranceApp.Application.Customers.Queries;

// ── GetCustomerById ───────────────────────────────────────────────────────────

public record GetCustomerByIdQuery(int Id) : IRequest<Result<CustomerDto>>;

public class GetCustomerByIdHandler : IRequestHandler<GetCustomerByIdQuery, Result<CustomerDto>>
{
    private readonly IUnitOfWork _unitOfWork;

    public GetCustomerByIdHandler(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<CustomerDto>> Handle(GetCustomerByIdQuery request, CancellationToken cancellationToken)
    {
        var customer = await _unitOfWork.Customers.GetByIdAsync(request.Id, cancellationToken);

        if (customer is null)
            return Result<CustomerDto>.Failure($"Customer with ID {request.Id} was not found.");

        return Result<CustomerDto>.Success(
            new(customer.Id, customer.FirstName, customer.LastName, customer.Email.Value,
                customer.Phone, customer.DateOfBirth, customer.Status.ToString(), customer.CreatedAt));
    }
}

// ── GetAllCustomers ───────────────────────────────────────────────────────────

public record GetAllCustomersQuery : IRequest<Result<IEnumerable<CustomerDto>>>;

public class GetAllCustomersHandler : IRequestHandler<GetAllCustomersQuery, Result<IEnumerable<CustomerDto>>>
{
    private readonly IUnitOfWork _unitOfWork;

    public GetAllCustomersHandler(IUnitOfWork unitOfWork)
    {
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<IEnumerable<CustomerDto>>> Handle(GetAllCustomersQuery request, CancellationToken cancellationToken)
    {
        var customers = await _unitOfWork.Customers.GetAllAsync(cancellationToken);

        var dtos = customers.Select(c =>
            new CustomerDto(c.Id, c.FirstName, c.LastName, c.Email.Value,
                c.Phone, c.DateOfBirth, c.Status.ToString(), c.CreatedAt));

        return Result<IEnumerable<CustomerDto>>.Success(dtos);
    }
}
