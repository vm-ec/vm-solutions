namespace InsuranceApp.Application.Common.Interfaces;

/// <summary>
/// Defined in Application so Infrastructure implements it — proper dependency inversion.
/// </summary>
public interface IEmailService
{
    Task SendWelcomeEmailAsync(string email, string fullName, CancellationToken cancellationToken = default);
    Task SendClaimApprovedEmailAsync(string email, string claimNumber, decimal amount, CancellationToken cancellationToken = default);
}

/// <summary>
/// Abstracts DateTime.UtcNow so it can be mocked in tests.
/// </summary>
public interface IDateTimeProvider
{
    DateTime UtcNow { get; }
}
