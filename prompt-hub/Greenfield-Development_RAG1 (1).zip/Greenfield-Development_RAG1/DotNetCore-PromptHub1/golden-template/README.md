# InsuranceApp - Golden Template

A complete, production-ready reference implementation for .NET Core greenfield development following **Clean Architecture + CQRS + Repository Pattern + Domain-Driven Design**.

## Purpose

This golden template is the reference implementation for the 21-step prompt workflow in `.github/Prompts/`. Use it to understand the target architecture and patterns when building your own application.

## Architecture

```
Client Request
    ↓
API Layer (Controllers — thin, dispatches via MediatR)
    ↓
Application Layer (CQRS Handlers, Pipeline Behaviours, Validators)
    ↓
Domain Layer (Entities, Value Objects, Interfaces — zero external dependencies)
    ↓
Infrastructure Layer (EF Core, Repositories, Unit of Work)
    ↓
Database (SQL Server)
```

## Project Structure

```
InsuranceApp/
├── src/
│   ├── InsuranceApp.Domain/              # Zero external dependencies
│   │   ├── Entities/                     # Customer, Policy, Claim (rich domain models)
│   │   ├── ValueObjects/                 # Email (immutable, self-validating)
│   │   ├── Enums/                        # CustomerStatus, PolicyType, ClaimStatus, etc.
│   │   ├── Interfaces/                   # IRepository<T>, IUnitOfWork, ICustomerRepository
│   │   └── Exceptions/                   # DomainException, NotFoundException
│   │
│   ├── InsuranceApp.Application/         # CQRS with MediatR
│   │   ├── Customers/
│   │   │   ├── Commands/                 # CreateCustomerCommand + Handler + Validator
│   │   │   └── Queries/                  # GetCustomerByIdQuery, GetAllCustomersQuery
│   │   └── Common/
│   │       ├── Behaviours/               # ValidationBehaviour, LoggingBehaviour
│   │       └── Models/                   # Result<T>, PagedResult<T>
│   │
│   ├── InsuranceApp.Infrastructure/      # EF Core implementations
│   │   ├── Data/
│   │   │   ├── ApplicationDbContext.cs
│   │   │   └── Configurations/           # Fluent API entity configurations
│   │   └── Repositories/                 # Repository<T>, CustomerRepository, UnitOfWork
│   │
│   └── InsuranceApp.API/                 # ASP.NET Core Web API
│       ├── Controllers/                  # CustomersController (thin, uses MediatR)
│       ├── Middleware/                   # ExceptionHandlingMiddleware
│       ├── Program.cs
│       └── appsettings.json
│
└── tests/
    └── InsuranceApp.UnitTests/           # xUnit + Moq unit tests
```

## Key Patterns Demonstrated

| Pattern | Where |
|---|---|
| Clean Architecture | 4 separate projects with inward dependency flow |
| CQRS | Commands (write) and Queries (read) in Application layer |
| MediatR Pipeline | ValidationBehaviour → LoggingBehaviour → Handler |
| Repository Pattern | Generic `IRepository<T>` + specific repositories |
| Unit of Work | `IUnitOfWork` wraps all repositories + SaveChanges |
| Value Objects | `Email` — immutable, self-validating |
| Rich Domain Model | Business logic in entities (not services) |
| Result Pattern | `Result<T>` — no exceptions for expected failures |
| Soft Delete | `IsDeleted` flag + EF Core global query filter |
| DI Extensions | `AddApplicationServices()`, `AddInfrastructureServices()` |

## Setup

1. Update connection string in `appsettings.json`
2. Run migrations:
   ```bash
   dotnet ef migrations add InitialCreate --project src/InsuranceApp.Infrastructure --startup-project src/InsuranceApp.API
   dotnet ef database update --project src/InsuranceApp.Infrastructure --startup-project src/InsuranceApp.API
   ```
3. Run the API:
   ```bash
   dotnet run --project src/InsuranceApp.API
   ```
4. Open Swagger: `https://localhost:5001/swagger`

## API Endpoints

### Customers
- `GET /api/customers` — Get all customers
- `GET /api/customers/{id}` — Get customer by ID
- `POST /api/customers` — Create new customer

## Extending the Template

To add a new feature (e.g., Policies):
1. Add entity in `Domain/Entities/`
2. Add repository interface in `Domain/Interfaces/`
3. Add Commands/Queries in `Application/[Feature]/`
4. Add EF configuration in `Infrastructure/Data/Configurations/`
5. Add repository implementation in `Infrastructure/Repositories/`
6. Register in `Infrastructure/DependencyInjection.cs`
7. Add controller in `API/Controllers/`
