# DotNetCore-PromptHub1

## 🚀 Overview
A complete AI-assisted toolkit for building enterprise-grade .NET Core applications from scratch following **Clean Architecture + CQRS + Domain-Driven Design**. This hub provides AI agents, coding instructions, step-by-step prompts, and a fully working reference implementation.

## 📁 Structure
```
DotNetCore-PromptHub1/
├── .github/
│   ├── Agents/                        # Specialized Copilot AI agents
│   │   ├── CSharpExpert.agent.md      # Expert C# code, patterns, SOLID advice
│   │   ├── plan.agent.md              # Strategic planning before implementation
│   │   ├── debug.agent.md             # Systematic bug finding and fixing
│   │   └── prompt-engineer.agent.md   # Improve or create new prompts
│   │
│   ├── Instructions/                  # Auto-applied Copilot coding rules
│   │   ├── copilot-instructions.md    # Master rules — architecture, CQRS, 21-step workflow
│   │   ├── csharp.instructions.md     # C# 14 standards (applies to **/*.cs)
│   │   ├── dotnet-core.instructions.md# Clean Architecture rules (applies to **/*.cs, **/*.csproj)
│   │   ├── guardrails.instructions.md # Security, performance guardrails (applies to **/*.cs)
│   │   ├── general-coding.instructions.md
│   │   └── guardrails.md
│   │
│   └── Prompts/                       # 21-step development workflow
│       ├── 01-solution-architecture-setup.prompt.md
│       ├── 02-domain-data-modeling.prompt.md
│       ├── 03-repository-data-access.prompt.md
│       ├── 04-cqrs-application-layer.prompt.md
│       ├── 05-api-layer-controllers.prompt.md
│       ├── 06-service-communication.prompt.md
│       ├── 07-logging-security-concerns.prompt.md
│       ├── 08-testing-quality.prompt.md
│       ├── 09-code-quality-standards.prompt.md
│       ├── 10-unit-test-creation.prompt.md
│       ├── 11-integration-testing.prompt.md
│       ├── 12-performance-optimization.prompt.md
│       ├── 13-microservices-architecture.prompt.md
│       ├── 14-event-driven-architecture.prompt.md
│       ├── 15-background-services.prompt.md
│       ├── 16-api-documentation.prompt.md
│       ├── 17-monitoring-observability.prompt.md
│       ├── 18-deployment-strategies.prompt.md
│       ├── 19-data-migration-tools.prompt.md
│       ├── 20-code-generation-tools.prompt.md
│       ├── 21-code-refactoring-automation.prompt.md
│       └── README.md                  # Step-by-step usage guide
│
├── golden-template/
│   └── InsuranceApp/                  # Complete reference implementation
│       ├── src/
│       │   ├── InsuranceApp.Domain/   # Zero external dependencies
│       │   ├── InsuranceApp.Application/  # CQRS with MediatR
│       │   ├── InsuranceApp.Infrastructure/  # EF Core, Repositories
│       │   └── InsuranceApp.API/      # Thin controllers, Program.cs
│       ├── tests/
│       │   ├── InsuranceApp.UnitTests/
│       │   └── InsuranceApp.ArchitectureTests/
│       ├── InsuranceApp.sln
│       └── README.md
│
└── README.md
```

## 🎯 Key Features
- **AI Agents**: Specialized Copilot agents for coding, planning, debugging, and prompt engineering
- **Auto-Applied Instructions**: Coding rules automatically enforced by Copilot on every code generation
- **21-Step Workflow**: Complete step-by-step prompts from solution setup to deployment
- **Golden Template**: A fully working, buildable reference implementation to copy patterns from
- **Clean Architecture**: Domain → Application → Infrastructure → API with strict inward dependencies
- **CQRS + MediatR**: Commands and Queries fully separated with pipeline behaviors
- **DDD**: Rich domain entities, Value Objects, Domain Events, Aggregate Roots
- **Security First**: JWT auth, guardrails, input validation built into instructions
- **Testing Ready**: Unit tests, integration tests, architecture tests included

## 🚀 Quick Start

### Step 1 — Open in VS Code
Open `DotNetCore-PromptHub1/` as your workspace. Copilot will automatically load all instructions from `.github/Instructions/`.

### Step 2 — Choose an Agent
Switch to the right Copilot agent for your task:
- Planning something? → Use `plan` agent
- Writing code? → Use `CSharpExpert` agent
- Fixing a bug? → Use `debug` agent

### Step 3 — Follow the 21 Prompts
Open `.github/Prompts/README.md` and follow the steps in order:
1. Start with `01-solution-architecture-setup` to scaffold your solution
2. Continue through each prompt sequentially
3. Test after each step before moving to the next

### Step 4 — Reference the Golden Template
When unsure how something should look, check `golden-template/InsuranceApp/` for a complete working example.

## 📖 21-Step Workflow Summary

| Group | Steps | What Gets Built |
|---|---|---|
| Foundation | 01–04 | Solution, Domain, Repository, CQRS |
| API Layer | 05–06 | Controllers, Service Communication |
| Security & Quality | 07–09 | Auth, Logging, Code Standards |
| Testing | 10–12 | Unit, Integration, Performance |
| Advanced | 13–15 | Microservices, Events, Background Services |
| Docs & Observability | 16–17 | Swagger, Monitoring, Health Checks |
| Deployment | 18–21 | Docker, CI/CD, Migrations, Refactoring |

## 🏗️ Architecture Pattern

```
Client Request
    ↓
API Layer (Controllers — thin, dispatches via MediatR)
    ↓
Application Layer (CQRS Handlers, Pipeline Behaviours, Validators)
    ↓
Domain Layer (Entities, Value Objects, Events — zero external dependencies)
    ↓
Infrastructure Layer (EF Core, Repositories, Unit of Work)
    ↓
Database (SQL Server)
```

## 🏆 Golden Template — InsuranceApp

A complete, production-ready reference implementation demonstrating all patterns:

| Pattern | Where |
|---|---|
| Clean Architecture | 4 projects with strict inward dependency flow |
| CQRS | Commands (write) and Queries (read) fully separated |
| MediatR Pipeline | ValidationBehaviour → LoggingBehaviour → Handler |
| Repository Pattern | Generic `IRepository<T>` + specific repositories |
| Unit of Work | `IUnitOfWork` wraps all repositories |
| Domain Events | Entities raise events (`PolicyCancelledEvent`, etc.) |
| Aggregate Root | `IAggregateRoot` marker on `Customer`, `Policy`, `Claim` |
| Value Objects | `Email` — immutable, self-validating |
| Rich Domain Model | Business logic in entities, not services |
| Result Pattern | `Result<T>` — no exceptions for expected failures |
| Soft Delete | `IsDeleted` flag + EF Core global query filter |
| Architecture Tests | NetArchTest enforces layer rules in CI |

### Setup
```bash
# Update connection string in appsettings.json, then:
dotnet ef migrations add InitialCreate --project src/InsuranceApp.Infrastructure --startup-project src/InsuranceApp.API
dotnet ef database update --project src/InsuranceApp.Infrastructure --startup-project src/InsuranceApp.API
dotnet run --project src/InsuranceApp.API
```
Open Swagger: `https://localhost:5001/swagger`

## 🛠️ Supported Technologies
- **.NET 8**: Web API, Clean Architecture, CQRS
- **MediatR**: Command/Query dispatching
- **FluentValidation**: Request validation
- **AutoMapper**: Entity ↔ DTO mapping
- **Entity Framework Core**: SQL Server, Code-First migrations
- **Serilog**: Structured logging
- **Swashbuckle**: Swagger/OpenAPI documentation
- **xUnit + Moq + FluentAssertions**: Testing
- **NetArchTest**: Architecture rule enforcement
- **Docker + GitHub Actions**: Containerization and CI/CD
